<?php get_header(); ?>
<h1><?php _e('Error') ?></span>404 - <?php _e('Not Found') ?></h1>
<h2>This is somewhat embarrassing, isn’t it?</h2>
<p>It seems we can’t find what you’re looking for. Perhaps searching can help.</p>
<?php get_search_form(); ?>
<?php get_footer(); ?>