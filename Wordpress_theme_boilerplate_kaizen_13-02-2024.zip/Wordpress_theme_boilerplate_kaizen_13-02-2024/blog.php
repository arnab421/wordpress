<?php /*Template Name: Layout: Blog*/?>
<?php get_header(); ?>
<div class="inner-banner-sec">
  <img src="<?php echo get_field('inner_banner_image');?>" alt="">
  <div class="inner-banner-content">
    <div class="container">
      <h2><?php echo get_field('inner_banner_heading');?></h2>
    </div>
  </div>
</div>


<div class="blog-sec common-padd blog-listing">
  <div class="container">
    <div class="blog-sec-wraper">
      <div class="row">
      <?php
            $args = array(
              'post_type' => 'post',
              'posts_per_page' => -1,
              'post_status' => 'publish',
              'order' => 'ASC',
            );
            $postdata = new WP_Query($args);
            if ($postdata->have_posts()) {
              while ($postdata->have_posts()) {
                $postdata->the_post();
                $postdata_image = wp_get_attachment_image_src(get_post_thumbnail_id($postdata->ID), 'full');
            ?>
        <div class="col-lg-4">
          <div class="sngl-blog">
            <div class="imge-box">
              <img src="<?php echo $postdata_image[0];?>" alt="">
              <div class="date"><?php the_time( 'j' ) ?> <span><?php the_time( 'M' )?></span></div>
            </div>
            <div class="content-box">
              <ul>
                <li><i class="fas fa-user-circle"></i> <?php echo get_field('author_name',$postdata->ID);?></li>
              </ul>
              <?php echo get_the_excerpt($postdata->ID); ?>
              <a class="read-more" href="<?php echo get_the_permalink($postdata->ID); ?>">Read More <i class="fa fa-long-arrow-alt-right"></i></a>
            </div>
          </div>
        </div>
        <?php }
            }

            wp_reset_postdata(); ?>
        
      </div>
    </div>
  </div>
</div>

<?php get_footer(); ?>