<?php //bloginfo('template_directory'); 
?>

<footer>
  <div class="container">
    <div class="footer-top">
      <div class="logo-ftr">
        <img src="<?php echo get_theme_value('site_footer_logo'); ?>">
      </div>
      <div class="footer-news-ltr">
        <h2><?php echo get_theme_value('footer_newsletter_heading'); ?></h2>
        <form>
          <div class="form-group">
            <input type="email" class="form-control" placeholder="Email " id="">
          </div>
          <input type="submit" value="Send">
        </form>
      </div>
    </div>
    <div class="footer-btm">
      <div class="row">
        <div class="col-lg-3">
          <div class="footer-contact">
            <h3><?php echo get_theme_value('footer_contact_heading'); ?></h3>
            <p> <?php echo get_theme_value('site_footer_shortdes'); ?></p>
            <ul>
              <li><a href="mailto:<?php echo get_theme_value('site_footer_email'); ?>"><i class="fa fa-envelope"></i><?php echo get_theme_value('site_footer_email'); ?></a></li>
              <li><a href="tel:<?php echo get_theme_value('site_footer_phone_number'); ?>"><i class="fa fa-phone-square"></i><?php echo get_theme_value('site_footer_phone_number'); ?></a></li>
            </ul>
          </div>
        </div>
        <div class="col-lg-3">
          <div class="footer-menu">
            <h3><?php echo get_theme_value('site_quicklink_heading'); ?></h3>
            
            <?php wp_nav_menu(array(
              'theme_location' => 'secondary',
              'container' => '',
              'items_wrap' => '<ul>%3$s</ul>',
            )); ?>
          </div>
        </div>
        <div class="col-lg-3">
          <div class="footer-menu">
            <h3><?php echo get_theme_value('site_services_heading'); ?></h3>
            
            <?php wp_nav_menu(array(
              'menu' => 'footer_bottom_menu',
              'container' => '',
              'menu_class' => '<ul>%3$s</ul>',
            )); ?>
          </div>
        </div>
        <div class="col-lg-3">
          <div class="footer-glry">
            <h3><?php echo get_theme_value('site_socialmedia_heading'); ?></h3>
            <ul>
              <!-- <li><a href=""><i class="fab fa-twitter"></i> Twitter</a></li>
              <li><a href=""><i class="fab fa-facebook-square"></i> Facebook</a></li>
              <li><a href=""><i class="fab fa-instagram"></i> Instagram</a></li>
              <li><a href=""><i class="fab fa-linkedin-in"></i> Linkedin</a></li> -->

              <?php
            $site_twitter_link = get_theme_value('site_twitter_link');
            $site_facebook_link = get_theme_value('site_facebook_link');
            $site_instragram_link = get_theme_value('site_instragram_link');
            $site_linkedin_link = get_theme_value('site_linkedin_link');
            if ($site_twitter_link != '') { ?>
              <li><a href="<?php echo $site_twitter_link?>" target="_blank"><i class="fab fa-twitter"></i> Twitter</a></li>
            <?php } ?>
            <?php if($site_facebook_link !=''){ ?>
            <li><a href="<?php echo $site_facebook_link;?>" target="_blank"><i class="fab fa-facebook-square"></i> Facebook</a></li>
            <?php } ?>
            <?php if($site_instragram_link !=''){ ?>
            <li><a href="<?php echo $site_instragram_link;?>" target="_blank"><i class="fab fa-instagram"></i> Instagram</a></li>
            <?php } ?>
            <?php if($site_linkedin_link !=''){ ?>
            <li><a href="<?php echo $site_linkedin_link;?>" target="_blank"><i class="fab fa-linkedin-in"></i> Linkedin</a></li>
            <?php } ?>
            </ul>
          </div>
        </div>
      </div>
    </div>
  </div>
</footer>

<div class="copyright-sec">
  <div class="container">
    <div class="row flex-row-reverse">
      <div class="col-lg-12">
        <p><?php echo get_theme_value('Footer_Copyright_Text');?></p>
      </div>
    </div>
  </div>
</div>
<?php wp_footer(); ?>
</body>

</html>