<?php get_header(); ?>
<?php if (have_posts()) : while (have_posts()) : the_post(); ?>

<div class="banner-sec">
  <div class="owl-carousel owl-theme" id="owl-carousel-banner">
  <?php
        if (have_rows('home_banner_content')) {
          while (have_rows('home_banner_content')) {
            the_row();
            $home_banner_image = get_sub_field('home_banner_image');
            $home_banner_heading = get_sub_field('home_banner_heading');
            $home_banner_short_text = get_sub_field('home_banner_short_text');
            $explore_now_button_text = get_sub_field('explore_now_button_text');
            $explore_now_button_link = get_sub_field('explore_now_button_link');
           
        ?>
    <div class="item">
      <img src="<?php echo $home_banner_image;?>" alt="">
      <div class="banner-content">
        <div class="container">
          <div class="inn-cntnt">
          <h5><?php echo $home_banner_heading;?></h5>
          <h1><?php echo $home_banner_short_text;?></h1>
          <a href="<?php echo $explore_now_button_link;?>" class="btn"><?php echo $explore_now_button_text;?></a>
        </div>
        </div>
      </div>
    </div>
    <?php }
        } ?>
    
  </div>
</div>


<div class="after-baner-sec">
  <div class="container">
    <div class="after-baner-sec-wraper-bg">
    <div class="after-baner-sec-wraper">
      <div class="row">
      <?php
        $i=0;
        if (have_rows('home_card_content')) {
          while (have_rows('home_card_content')) {
            the_row();
            $i++;
            $card_heading = get_sub_field('card_heading');
            $card_short_text = get_sub_field('card_short_text');
           
        ?>
        <div class="col-lg-4">
          <div class="sngl-box">
            <div class="img-box">
              <div class="number"><?php echo $i;?></div>
              <div class="img-sec">
                <i class="fas fa-passport"></i>
              </div>
            </div>
            <div class="contebt-box">
              <h5><?php echo $card_heading;?></h5>
              <p><?php echo $card_short_text;?></p>
            </div>
          </div>
        </div> 
        <?php }
        } ?>
       
      </div>
      <div class="box-text">
      <p><?php echo get_field('card_bottom_notice_text');?></p>
    </div>
    </div>
  </div>
  </div>
</div>


<div class="about-sec common-padd">
  <div class="container">
    <div class="row align-items-center">
      <div class="col-lg-6">
        <div class="lft-image">
          <img src="<?php echo get_field('home_about_section_image');?>" alt="">
          <div class="expo">
            <h4><?php echo get_field('home_about_experience_text');?></h4>
          </div>
        </div>
      </div>
      <div class="col-lg-6">
        <div class="content-ares">
           <?php the_content();?>
        </div>
      </div>
    </div>
  </div>
</div>

<div class="services-sec">
  <div class="services-top-sec">
    <div class="services-top-sec-wraper">
      <div class="container">
        <h4><?php echo get_field('home_service_heading');?></h4>
        <h2><?php echo get_field('home_service_short_text');?></h2>

      </div>
    </div>
  </div>
  <div class="services-btm-sec">
    <div class="container">
      <div class="owl-carousel owl-theme" id="owl-carousel-srvcs">
      <?php
            $args = array(
              'post_type' => 'services',
              'posts_per_page' => -1,
              'post_status' => 'publish',
              'order' => 'DESC',
            );
            $services = new WP_Query($args);
            if ($services->have_posts()) {
              while ($services->have_posts()) {
                $services->the_post();
                $service_image = wp_get_attachment_image_src(get_post_thumbnail_id($services->ID), 'full');
            ?>
        <div class="item">
          <div class="sngl-box">
            <a href="<?php echo get_the_permalink($services->ID); ?>">
              <div class="imge-box">
                <img src="<?php echo $service_image[0];?>">
              </div>
              <div class="content-box">
                <h4><?php echo get_the_title();?></h4>
                <?php echo get_the_excerpt($services->ID);?>
              </div>
            </a>
          </div>
        </div>
        <?php }
            }

            wp_reset_postdata(); ?>
        
      </div>
    </div>
  </div>
</div>


<div class="faq-sec common-padd reletive-sec">
  <div class="container">
    <div class="row">
      <div class="col-lg-6">
        <div class="lft-text">
          <h4><?php echo get_field('faq_heading');?></h4>
          <h2><?php echo get_field('faq_short_text');?></h2>
          <p><?php echo get_field('faq_short_description');?></p>
          <div class="accordion" id="faq">
          <?php
          $j=0;
      if (have_rows('faq_accordion_content')) {
           while (have_rows('faq_accordion_content')) {
            the_row();
            $j++;
            $accordion_heading = get_sub_field('accordion_heading');
            $accordion_short_description = get_sub_field('accordion_short_description');
            if($j == 1){
              $showclass ='show';
            }
            else {
              $showclass ='';
            }
        ?>
                    <div class="card">
                        <div class="card-header" id="faqhead<?php echo $j;?>">
                            <a href="#" class="btn btn-header-link" data-toggle="collapse" data-target="#faq<?php echo $j;?>"
                            aria-expanded="true" aria-controls="faq<?php echo $j;?>"><?php echo $accordion_heading;?></a>
                        </div>

                        <div id="faq<?php echo $j;?>" class="collapse <?php echo $showclass;?>" aria-labelledby="faqhead<?php echo $j;?>" data-parent="#faq">
                            <div class="card-body">
                                <p><?php echo $accordion_short_description;?></p>
                            </div>
                        </div>
                    </div>
                    <?php }
        } ?>
                    
                </div>
        </div>
      </div>
      <div class="col-lg-6">
        <div class="rightimage-box">
          <div class="top-sec">
            <div class="img-sec">
              <i class="fas fa-passport"></i>
            </div>
            <h3><?php echo get_field('year_of_experience_text');?></h3>
          </div>
          <div class="btm-image">
          <img src="<?php echo get_field('right_consultancy_image');?>" alt="">
          <div class="expo">
            <h4><?php echo get_field('agency_text');?></h4>
          </div>
        </div>
        </div>
      </div>
    </div>
  </div>
</div>

<div class="colling-action">
  <div class="container">
    <h4><?php echo get_field('visa_application_text');?> <a href="tel:+<?php echo get_field('visa_phone_number');?>" class="info-btn"><i class="fas fa-phone"></i> <?php echo get_field('visa_phone_number');?></a></h4>
  </div>
</div>

<div class="blog-sec common-padd">
  <div class="container">
    <div class="section-header">
      <h4><?php echo get_field('recent_news_feed_heading');?></h4>
      <h2><?php echo get_field('recent_article_heading');?></h2>
    </div>
    <div class="blog-sec-wraper">
      <div class="row">
      <?php
            $args = array(
              'post_type' => 'post',
              'posts_per_page' => 3,
              'post_status' => 'publish',
              'order' => 'ASC',
            );
            $postdata = new WP_Query($args);
            if ($postdata->have_posts()) {
              while ($postdata->have_posts()) {
                $postdata->the_post();
                $postdata_image = wp_get_attachment_image_src(get_post_thumbnail_id($postdata->ID), 'full');
            ?>
        <div class="col-lg-4">
          <div class="sngl-blog">
            <div class="imge-box">
              <img src="<?php echo $postdata_image[0];?>" alt="">
              <div class="date"><?php the_time( 'j' ) ?> <span><?php the_time( 'M' ) ?></span></div>
            </div>
            <div class="content-box">
              <ul>
                <li><i class="fas fa-user-circle"></i> <?php echo get_field('author_name',$postdata->ID);?></li>
              </ul>
              <?php echo get_the_excerpt($postdata->ID); ?>
              <a class="read-more" href="<?php echo get_the_permalink($postdata->ID); ?>">Read More <i class="fa fa-long-arrow-alt-right"></i></a>
            </div>
          </div>
        </div>
        <?php }
            }

            wp_reset_postdata(); ?>
        
      </div>
      <div class="end-btn">
        <a href="<?php echo get_field('all_blog_button_link');?>" class="btn"> View All</a>
      </div>
    </div>
  </div>
</div>



<div class="testimonial common-padd">
  <div class="testimonial-wraper">
    <div class="container">
      <div class="section-header">
        <h2><?php echo get_field('testimonial_heading');?></h2>
      </div>
      <div class="testi-sec">
        <div class="owl-carousel owl-theme" id="owl-carousel-testi">
        <?php
            $args = array(
              'post_type' => 'testimonials',
              'posts_per_page' => -1,
              'post_status' => 'publish',
              'order' => 'DESC',
            );
            $testimonials = new WP_Query($args);
            if ($testimonials->have_posts()) {
              while ($testimonials->have_posts()) {
                $testimonials->the_post();
                $testimonial_image = wp_get_attachment_image_src(get_post_thumbnail_id($testimonials->ID), 'full');
            ?>
          <div class="item">
            <div class="testi-wraper">
              <div class="testi-user">
                <img src="<?php echo $testimonial_image[0];?>" alt="">
              </div>
              <div class="testi-describe">
                <h4><?php echo get_the_title();?></h4>
                <?php echo get_the_excerpt($services->ID);?>
              </div>
            </div>
          </div>
          <?php }
            }

            wp_reset_postdata(); ?>
          
        </div>
      </div>
    </div>
  </div>
</div>

<?php endwhile;
endif; ?>
<?php get_footer(); ?>