<?php
add_action('init','web_ftn_options');
if(!function_exists('web_ftn_options')){
	function web_ftn_options(){
		// If using image radio buttons,define a directory path
		$imagepath = get_stylesheet_directory_uri().'/images/'; 
		$options = array(
		/* ---------------------------------------------------------------------------- */
		/* Header Setting */
		/* ---------------------------------------------------------------------------- */
		array("name" => "Header Section",
			  "type" => "heading"),
		
		array("name" => "Choose Site Logo",
			  "desc" => "Choose Site Logo",
			  "id"   => "site_header_logo",
			  "std"  => "",
			  "type" => "upload"),
		array("name" => "Header Email Address",
			  "desc" => "Header Email Address",
			  "id"   => "header_email_address",
			  "std"  => "",
			  "type" => "text"),
	    array("name" => "Header Address",
			  "desc" => "Header Address",
			  "id"   => "site_header_address",
			  "std"  => "",
			  "type" => "text"),
		/* ---------------------------------------------------------------------------- */
		/* Footer Setting */
		/* ---------------------------------------------------------------------------- */
		array("name" => "Footer Section",
			  "type" => "heading"),
		
		array("name" => "Choose Footer Logo",
			  "desc" => "Choose Footer Logo",
			  "id"   => "site_footer_logo",
			  "std"  => "",
			  "type" => "upload"),
		array("name" => "Footer Newsletter Heading",
			  "desc" => "Footer Newsletter Heading",
			  "id"   => "footer_newsletter_heading",
			  "std"  => "",
			  "type" => "text"),
		array("name" => "Footer Contact Heading",
			  "desc" => "Footer Contact Heading",
			  "id"   => "footer_contact_heading",
			  "std"  => "",
			  "type" => "text"),
	    array("name" => "Footer Short Description",
			  "desc" => "Footer Short Description",
			  "id"   => "site_footer_shortdes",
			  "std"  => "",
			  "type" => "textarea"),
	    array("name" => "Footer Email Address",
			  "desc" => "Footer Email Address",
			  "id"   => "site_footer_email",
			  "std"  => "",
			  "type" => "text"),
		array("name" => "Footer Phone Number",
			  "desc" => "Footer Phone Number",
			  "id"   => "site_footer_phone_number",
			  "std"  => "",
			  "type" => "text"),
		array("name" => "Footer Quick Link Heading",
			  "desc" => "Footer Quick Link Heading",
			  "id"   => "site_quicklink_heading",
			  "std"  => "",
			  "type" => "text"),
		array("name" => "Footer Services Heading",
			  "desc" => "Footer Services Heading",
			  "id"   => "site_services_heading",
			  "std"  => "",
			  "type" => "text"),
		array("name" => "Footer Socialmedia Heading",
			  "desc" => "Footer Socialmedia Heading",
			  "id"   => "site_socialmedia_heading",
			  "std"  => "",
			  "type" => "text"),
	     	      
	   array("name" => "Footer Copyright Text",
			  "desc" => "Footer Copyright Text",
			  "id"   => "Footer_Copyright_Text",
			  "std"  => "",
			  "type" => "text"),
	 
	   /* ---------------------------------------------------------------------------- */
       /* Social Media Setting */
       /* ---------------------------------------------------------------------------- */
      array("name" => "Social Media Setting",
		"type" => "heading"),
		array("name" => "Site Twitter Link",
		"desc" => "Site Twitter Link",
		"id"   => "site_twitter_link",
		"std"  => "",
		"type" => "text"),
      array("name" => "Site Facebook Link",
		"desc" => "Site Facebook Link",
		"id"   => "site_facebook_link",
		"std"  => "",
		"type" => "text"),		
	  array("name" => "Site Instragram Link",
		"desc" => "Site Instragram Link",
		"id"   => "site_instragram_link",
		"std"  => "",
		"type" => "text"),   	  
	  array("name" => "Site Linkedin Link",
		"desc" => "Site Linkedin Link",
		"id"   => "site_linkedin_link",
		"std"  => "",
		"type" => "text"),			
			);		
		web_ftn_update_option('of_template',$options);
		}
	}
?>