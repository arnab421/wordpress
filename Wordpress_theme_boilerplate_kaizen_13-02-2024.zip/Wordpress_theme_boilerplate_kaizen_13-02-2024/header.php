<!DOCTYPE html>
<html <?php language_attributes(); ?>>

<head>
  <meta charset="<?php bloginfo('charset'); ?>">
  <meta http-equiv="X-UA-Compatible" content="IE=edge">
  <meta name="viewport" content="width=device-width,initial-scale=1.0">
  <link rel="profile" href="http://gmpg.org/xfn/11" />
  <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.14.0/umd/popper.min.js"></script>
  <script src="https://cdnjs.cloudflare.com/ajax/libs/waypoints/4.0.0/jquery.waypoints.min.js"></script>
  <?php wp_head(); ?>
</head>
<!--/head-->
<?php if (is_front_page()) {
  $class = 'home';
} else {
  $class = '';
} ?>

<body <?php body_class($class); ?>>
  <!--header sction-->
  <header class="main-header">
    <div class="container-fluid header-row">
      <div class="logo">
        <a href="<?php echo home_url(); ?>"><img src="<?php echo get_theme_value('site_header_logo'); ?>" alt=""></a>
      </div>
      <div class="all-menus">
        <div class="menu-top">
          <ul class="head-address">
            <li><a href="mailto:<?php echo get_theme_value('header_email_address'); ?>"><span><i class="fas fa-envelope"></i></span> <?php echo get_theme_value('header_email_address'); ?></a></li>
            <li><a href="#"><span><i class="fas fa-map-marker"></i></span> <?php echo get_theme_value('site_header_address'); ?></a></li>
          </ul>
          <ul class="head-media">
            <?php
            $site_twitter_link = get_theme_value('site_twitter_link');
            $site_facebook_link = get_theme_value('site_facebook_link');
            $site_instragram_link = get_theme_value('site_instragram_link');
            $site_linkedin_link = get_theme_value('site_linkedin_link');
            if ($site_twitter_link != '') { ?>
              <li><a href="<?php echo $site_twitter_link?>" target="_blank"><i class="fab fa-twitter"></i></a></li>
            <?php } ?>
            <?php if($site_facebook_link !=''){ ?>
            <li><a href="<?php echo $site_facebook_link;?>" target="_blank"><i class="fab fa-facebook-square"></i></a></li>
            <?php } ?>
            <?php if($site_instragram_link !=''){ ?>
            <li><a href="<?php echo $site_instragram_link;?>" target="_blank"><i class="fab fa-instagram"></i></a></li>
            <?php } ?>
            <?php if($site_linkedin_link !=''){ ?>
            <li><a href="<?php echo $site_linkedin_link;?>" target="_blank"><i class="fab fa-linkedin-in"></i></a></li>
            <?php } ?>
          </ul>
        </div>
        <div class="menu-btm">
          <div class="hdr-rt">
            <div class="main-menu">
              <div class="nav_close" onclick="menu_close()">
                <i class="far fa-times-circle"></i>
              </div>

              <?php wp_nav_menu(array(
                'theme_location' => 'primary',
                'container' => '',
                'items_wrap' => '<ul>%3$s</ul>',
              )); ?>
            </div>
            <div onclick="menu_open()" class="nav_btn">
              <i class="fas fa-bars"></i>
            </div>
          </div>
        </div>
      </div>
  </header>

  <!--header sction-->