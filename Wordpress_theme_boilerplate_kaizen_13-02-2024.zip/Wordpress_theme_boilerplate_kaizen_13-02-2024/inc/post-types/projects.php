<?php
/***
* Projects Post Type
***/

if(! class_exists('Progressive_Projects_Post_Type')):
class Progressive_Projects_Post_Type{

	function __construct(){
		// Adds the projects post type 
		add_action('init',array(&$this,'projects_init'),0);
		// Thumbnail support for projects posts
		add_theme_support('post-thumbnails',array('projects'));
	}
	

	function projects_init(){
		/**
		 * Enable the Projects custom post type
		 * http://codex.wordpress.org/Function_Reference/register_post_type
		 */
		$labels = array(
			'name'					=> __('Projects','Progressive'),
			'singular_name'		=> __('Projects','Progressive'),
			'add_new'				=> __('Add New','Progressive'),
			'add_new_item'			=> __('Add New Project','Progressive'),
			'edit_item'			=> __('Edit Project','Progressive'),
			'new_item'				=> __('Add New Project','Progressive'),
			'view_item'			=> __('View Project','Progressive'),
			'search_items'			=> __('Search Projects','Progressive'),
			'not_found'			=> __('No Projects items found','Progressive'),
			'not_found_in_trash'	=> __('No Projects found in trash','Progressive')
		);
		
		$args = array(
		    'labels' => $labels,
			'public' => true,
			'publicly_queryable' => true,
			'show_ui' => true,
			'query_var' => true,
			'menu_icon' => 'dashicons-clipboard',			
			'map_meta_cap' => true,
			'hierarchical' => false,
			'menu_position' => 5,
			'supports' => array('title','thumbnail','editor','page-attributes','excerpt')
		); 
				
		$args = apply_filters('Progressive_projects_args',$args);
		
		register_post_type('projects',$args);
		
		// Add new taxonomy,NOT hierarchical(like tags)
		$labels_one = array(
			'name'                       => _x('Project Types','taxonomy general name'),
			'singular_name'              => _x('Project Type','taxonomy singular name'),
			'search_items'               => __('Search Project Types'),
			'popular_items'              => __('Popular Project Types'),
			'all_items'                  => __('All Project Types'),
			'parent_item'                => null,
			'parent_item_colon'          => null,
			'edit_item'                  => __('Edit Project Type'),
			'update_item'                => __('Update Project Type'),
			'add_new_item'               => __('Add New Project Type'),
			'new_item_name'              => __('New Project Type Name'),
			'separate_items_with_commas' => __('Separate project types with commas'),
			'add_or_remove_items'        => __('Add or remove project types'),
			'choose_from_most_used'      => __('Choose from the most used project types'),
			'not_found'                  => __('No project types found.'),
			'menu_name'                  => __('Project Types'),
		);
	
		$args_one = array(
			'hierarchical'          => true,
			'labels'                => $labels_one,
			'show_ui'               => true,
			'show_admin_column'     => true,
			'update_count_callback' => '_update_post_term_count',
			'query_var'             => true,
			'rewrite'               => array('slug' => 'project_type'),
		);
	
		register_taxonomy('project_type','projects',$args_one);		
	}
}

new Progressive_Projects_Post_Type;
endif;