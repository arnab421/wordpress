function menu_open() {
    jQuery(".main-menu").css({"transform":"translateX(0)"}) 
}
function menu_close() { 
    jQuery(".main-menu").css({"transform":"translateX(320px)"})
}

// jQuery(window).scroll(function(){
//   if (jQuery(window).scrollTop() >= 100) {
//     jQuery('header').addClass('fixed');
//    }
//    else {
//     jQuery('header').removeClass('fixed');
//    }
// });

jQuery(document).ready(function(){
jQuery('#owl-carousel-banner').owlCarousel({
    loop:true,
    margin:10,
    responsiveClass:true,
    autoplay:true,
    autoplayTimeout:5000,
    responsive:{
        0:{
            items:1,
            nav:true
        },
        600:{
            items:1,
            nav:true
        },
        1000:{
            items:1,
            nav:true,
            loop:true
        }
    }
})
});

jQuery(document).ready(function(){
jQuery('#owl-carousel-srvcs').owlCarousel({
    loop:true,
    margin:10,
    responsiveClass:true,
    autoplay:true,
    autoplayTimeout:5000,
    responsive:{
        0:{
            items:1,
            nav:true
        },
        600:{
            items:2,
            nav:true
        },
        1000:{
            items:4,
            nav:true,
            loop:true
        }
    }
})
});

jQuery(document).ready(function(){
jQuery('#owl-carousel-testi').owlCarousel({
    loop:true,
    margin:10,
    responsiveClass:true,
    responsive:{
        0:{
            items:1,
            nav:true
        },
        600:{
            items:2,
            nav:false
        },
        1000:{
            items:3,
            nav:true,
            loop:true,
        }
    }
})
});