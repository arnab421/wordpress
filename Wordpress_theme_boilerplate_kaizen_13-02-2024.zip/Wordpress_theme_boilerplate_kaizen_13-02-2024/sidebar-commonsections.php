

<?php
 $big_image = get_theme_value('big_image');
 $phone_image = get_theme_value('phone_image');
 $site_quote_text = get_theme_value('site_quote_text');
 $site_appointment_text = get_theme_value('site_appointment_text');
 $site_appointment_link = get_theme_value('site_appointment_link');
 
 ?>
<div class="footer-top">
  <div class="container">
    <div class="girl-img">
      <img src="<?php echo $big_image;?>" alt="">
    </div>
    <div class="content-box">
      <ul>
        <li><span><img src="<?php echo $phone_image?>"></span> <?php echo $site_quote_text;?></li>
        <li><a href="<?php echo $site_appointment_link;?>" class="btn white-btn"> <?php echo $site_appointment_text;?></a></li>
      </ul>
    </div>
  </div>
</div>