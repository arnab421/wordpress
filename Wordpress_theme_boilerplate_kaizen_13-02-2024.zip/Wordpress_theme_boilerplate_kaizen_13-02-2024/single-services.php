<?php get_header('');
if (have_posts()) : while (have_posts()) : the_post();
?> 

<div class="inner-banner-sec">
  <img src="<?php echo get_field('inner_banner_image');?>" alt="">
  <div class="inner-banner-content">
    <div class="container">
      <h2><?php echo get_field('inner_banner_heading');?></h2>
    </div>
  </div>
</div>


<div class="services-details common-padd">
  <div class="container">
   
    <?php the_content();?>
    <div class="box-wrap">
      <div class="row">
        <div class="col-lg-6">
          <div class="lft-content">
            
            <?php echo get_field('service_details_page_box_content');?>
          </div>
        </div>
        <div class="col-lg-6">
          <div class="right-img">
            <img src="<?php echo get_field('service_page_big_image_right_side');?>" alt="">
          </div>
          </div>
        </div>
      </div>
      
    <?php echo get_field('sevice_page_bottom_content');?>
    </div>
  </div>
</div>

<?php endwhile; endif; ?>
<?php get_footer(); ?>