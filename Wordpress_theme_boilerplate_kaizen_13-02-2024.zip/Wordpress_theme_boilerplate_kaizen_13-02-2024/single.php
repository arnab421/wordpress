<?php get_header(); 
if (have_posts()) : while (have_posts()) : the_post();
?> 
<div class="blog-details-page common-padd">
  <div class="container">
    <div class="row">
      <div class="col-lg-8">
        <div class="blog-details-lft">
          <div class="blog-dtls-img">
            <img src="<?php echo get_field('blog_post_details_page_image');?>" alt="">
          </div>
          <div class="blog-dtls-content">
           
            <?php the_content();?>
            <div class="shear-blog">
              <ul>
                <li class="fb"><a href="https://www.facebook.com/sharer?u=<?php the_permalink(); ?>&amp;t=<?php the_title(); ?>" target="_blank" rel="noopener noreferrer"><i class="fab fa-facebook-f"></i> Facebook</a></li>
                <li class="tt"><a href="http://twitter.com/intent/tweet?text=<?php the_title(); ?>&amp;url=<?php the_permalink(); ?>" target="_blank" rel="noopener noreferrer"><i class="fab fa-twitter"></i> Twitter</a></li>
              </ul>
            </div>
          </div>
        </div>
      </div>
      <div class="col-lg-4">
        <div class="releted-blog">
          <h5>Recent Post</h5>
          <?php
           $args = array(
                'post_type' => 'post',
                'post_status' => 'publish',
                'posts_per_page' => -1,
                'post__not_in' => array( $post->ID ),
                'tax_query' => array(
                    array(
                        'taxonomy' => 'category',
                        'field'    => 'slug',
                        'terms'    => 'recent',
                        'operator' => 'IN'
                    ),
                ),
            );
            $postdata = new WP_Query($args);
            if ($postdata->have_posts()) {
              while ($postdata->have_posts()) {
                $postdata->the_post();
                $postdata_image = wp_get_attachment_image_src(get_post_thumbnail_id($postdata->ID), 'full');
            ?>
          <div class="releted-blog-box">
            <a href="<?php echo get_the_permalink($postdata->ID); ?>">
            <div class="recent-blog-thmbl">
              <img src="<?php echo $postdata_image[0];?>" alt="">
            </div>
            <div class="recent-blog-cntnt">
              <!-- <h2>Lorem Ipsum is simply</h2>
              <p>Lorem Ipsum is simply dummy text of the printing and typesetting industry.</p> -->
              <?php echo get_the_excerpt($postdata->ID); ?>
            </div>
            </a>
          </div>
          <?php }
            }

            wp_reset_postdata(); ?>
          
        </div>
      </div>
    </div>
  </div>
</div>			
<?php endwhile; endif; ?>
<?php get_footer(); ?>