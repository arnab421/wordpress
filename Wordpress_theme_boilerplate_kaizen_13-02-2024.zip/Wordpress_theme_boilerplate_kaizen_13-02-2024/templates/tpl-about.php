<?php /*Template Name: Layout: About*/ ?>
<?php get_header('');
?> 
<div class="inner-banner-sec">
  <img src="<?php echo get_field('inner_banner_image');?>" alt="">
  <div class="inner-banner-content">
    <div class="container">
      <h2><?php echo get_field('inner_banner_heading');?></h2>
    </div>
  </div>
</div>


<div class="about-sec common-padd about-page-top">
  <div class="container">
    <div class="row align-items-center">
      <div class="col-lg-5">
        <div class="lft-image">
          <img src="<?php echo get_field('client_big_image');?>" alt="">
        </div>
      </div>
      <div class="col-lg-7">
        <div class="content-ares">
          
          <?php echo get_field('about_description');?>
        </div>
      </div>
    </div>
  </div>
</div>


<div class="colling-action">
  <div class="container">
    <h4><?php echo get_field('visa_application_text');?> <a href="tel:+<?php echo get_field('visa_application_phone_number');?>" class="info-btn"><i class="fas fa-phone"></i> <?php echo get_field('visa_application_phone_number');?></a></h4>
  </div>
</div>



<div class="aboutus-third-sec common-padd">
  <div class="container">
    <div class="row">
      <div class="col-lg-6">
        <div class="about-third-lft-img">
          <img src="<?php echo get_field('about_faq_section_image');?>" alt="">
        </div>
      </div>
      <div class="col-lg-6">
        <div class="about-thid-right">
            <div class="accordion" id="faq">
            <?php
          $j=0;
      if (have_rows('about_faq_content')) {
           while (have_rows('about_faq_content')) {
            the_row();
            $j++;
            $about_faq_heading = get_sub_field('about_faq_heading');
            $about_faq_description = get_sub_field('about_faq_description');
            if($j == 1){
              $showclass ='show';
            }
            else {
              $showclass ='';
            }
        ?>
                    <div class="card">
                        <div class="card-header" id="faqhead<?php echo $j;?>">
                            <a href="#" class="btn btn-header-link" data-toggle="collapse" data-target="#faq<?php echo $j;?>"
                            aria-expanded="true" aria-controls="faq<?php echo $j;?>"><?php echo $about_faq_heading;?></a>
                        </div>

                        <div id="faq<?php echo $j;?>" class="collapse <?php echo $showclass;?>" aria-labelledby="faqhead<?php echo $j;?>" data-parent="#faq">
                            <div class="card-body">
                               <p><?php echo $about_faq_description;?></p>
                            </div>
                        </div>
                    </div>
                    <?php }
                  } ?>
                    
                </div>
        </div>
      </div>
    </div>
  </div>
</div>
<?php get_footer(); ?>