<?php /*Template Name: Layout: Architeture*/?>
<?php get_header(); ?>
<div class="inner-banner">
  <img src="<?php echo get_field('inner_banner_image');?>">
    <div class="inner-banner-text">
      <div class="container">
        <h2><?php echo get_field('inner_banner_heading');?></h2>
      </div>
    </div>
</div>


<div class="our-work-page common-padd">
  <div class="container">
    <div class="row">
      <div class="col-lg-12">
      <?php
            $paged = (get_query_var('paged')) ? get_query_var('paged') : 1; 
            $args = array(
                'post_type' => 'post',
                'post_status' => 'publish',
                'posts_per_page' => 1,
                'tax_query' => array(
                    array(
                        'taxonomy' => 'category',
                        'field'    => 'slug',
                        'terms'    => 'architecture',
                        'operator' => 'IN'
                    ),
                ),
            );
            $postdata = new WP_Query($args);
            if ($postdata->have_posts()) {
              while ($postdata->have_posts()) {
                $postdata->the_post();
                $postdata_image = wp_get_attachment_image_src(get_post_thumbnail_id($postdata->ID), 'full');
            ?>
        <div class="blog-lft-box">
          <h3><?php echo get_the_title();?></h3>
          <div class="blog-lft-box-wraper">
            <div class="row">
              <div class="col-lg-5">
                <div class="blog-lft-box-img">
                  <img src="<?php echo $postdata_image[0];?>" alt="">
                </div>
              </div>
              <div class="col-lg-7">
                <div class="blog-lft-box-content">
                  <p><?php echo get_the_excerpt($postdata->ID); ?> </p>
                  
                  <a href="<?php echo get_the_permalink($postdata->ID); ?>" class="btn">Read More</a>
                </div>
              </div>
            </div>
          </div>
        </div> 
        <?php }
            }

            wp_reset_postdata(); ?>
        
        
      </div>
    </div>
  </div>
</div>
<!-- pagination -->
<div class="container">
  <div class="row">

    <div class="col-sm-12 pt-4">
      <?php
      if (!function_exists('post_pagination')) :
        function post_pagination()
        {
          global $postdata;
          $pager = 999999999; // need an unlikely integer

          echo paginate_links(array(
            'base' => str_replace($pager, '%#%', esc_url(get_pagenum_link($pager))),
            'format' => '?paged=%#%',
            'current' => max(1, get_query_var('paged')),
            'total' => $postdata->max_num_pages
          ));
        }
      endif;
      ?>
      <ul class="pagination justify-content-center">

        <?php post_pagination(); ?>
      </ul>
    </div>
  </div>
</div>
<!-- pagination -->
<?php get_sidebar('commonsections'); ?>

<?php get_footer(); ?>