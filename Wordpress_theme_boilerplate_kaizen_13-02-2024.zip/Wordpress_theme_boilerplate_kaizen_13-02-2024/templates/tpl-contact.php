


<?php /*Template Name: Layout: Contact*/ ?>
<?php get_header('');
?>
<div class="inner-banner-sec">
  <img src="<?php echo get_field('inner_banner_image');?>" alt="">
  <div class="inner-banner-content">
    <div class="container">
      <h2><?php echo get_field('inner_banner_heading');?></h2>
    </div>
  </div>
</div>


<div class="contact-page common-padd">
  <div class="container">
    <div class="row">
      <div class="col-lg-6 nopadd">
        <div class="contactbox">
        <div class="contact-info">
          <h2><?php echo get_field('contact_info_heading');?></h2>
          <p><?php echo get_field('contact_short_description');?> </p>
          <ul>
        <li><img src="<?php echo get_field('location_image');?>" alt="location"> <?php echo get_field('location_address');?></li>

    <li><img src="<?php echo get_field('call_image');?>" alt="location">  <?php echo get_field('call_phone_number');?></li>
            <li><img src="<?php echo get_field('contact_email_logo');?>" alt="location">   <?php echo get_field('contact_email');?></li>
          </ul>
        </div>
      </div>
      </div>
      <div class="col-lg-6 nopadd">
        <div class="contactbox">
        <div class="contact-form bluebg">
          <h3><?php echo get_field('contact_form_heading');?></h3>
          <!-- <form action="/action_page.php">
            <div class="form-group">
              <input type="text" class="form-control" placeholder="Name" id="">
            </div>
            <div class="form-group">
              <input type="email" class="form-control" placeholder="Email " id="">
            </div>
            <div class="form-group">
              <input type="tel" class="form-control" placeholder="00000 00000" id="">
            </div>
            <div class="form-group">
              <textarea class="form-control" rows="5" id="" placeholder="Message "></textarea>
            </div>
            <button type="submit" class="btn whitebtn">Submit</button>
          </form> -->
          <?php echo do_shortcode( '[contact-form-7 id="181" title="Contact form 1"]' );?>
        </div>
      </div>
      </div>
    </div>
  </div>
</div>

<div class="map-sec">
  <iframe src="<?php echo get_field('contact_page_map_iframe');?>" width="100%" height="100%" style="border:0;" allowfullscreen="" loading="lazy" referrerpolicy="no-referrer-when-downgrade"></iframe>
</div>

<?php get_footer(); ?> 