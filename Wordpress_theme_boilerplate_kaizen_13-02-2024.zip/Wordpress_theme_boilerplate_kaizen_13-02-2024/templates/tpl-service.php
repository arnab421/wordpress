<?php /*Template Name: Layout: Service*/ ?>
<?php get_header('');
?> 
<div class="inner-banner-sec">
  <img src="<?php echo get_field('inner_banner_image');?>" alt="">
  <div class="inner-banner-content">
    <div class="container">
      <h2><?php echo get_field('inner_banner_heading');?></h2>
    </div>
  </div>
</div>

<div class="services-sec srvc-page common-padd">
  <div class="services-btm-sec">
    <div class="container">
      <div class="row">
      <?php
            $args = array(
              'post_type' => 'services',
              'posts_per_page' => -1,
              'post_status' => 'publish',
              'order' => 'DESC',
            );
            $services = new WP_Query($args);
            if ($services->have_posts()) {
              while ($services->have_posts()) {
                $services->the_post();
                $service_image = wp_get_attachment_image_src(get_post_thumbnail_id($services->ID), 'full');
            ?>
        <div class="col-lg-4">
          <div class="sngl-box">
            <a href="<?php echo get_the_permalink($services->ID); ?>">
              <div class="imge-box">
                <img src="<?php echo $service_image[0];?>">
              </div>
              <div class="content-box">
                <h4><?php echo get_the_title();?></h4>
                <!-- <p>Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod
                tempor incididunt.</p> -->
                <?php echo get_the_excerpt($services->ID);?>
              </div>
            </a>
          </div>
        </div>
        <?php }
            }

            wp_reset_postdata(); ?>
        <!-- <div class="col-lg-4">
          <div class="sngl-box">
            <a href="">
              <div class="imge-box">
                <img src="images/img2.jpg">
              </div>
              <div class="content-box">
                <h4>Express Entry</h4>
                <p>Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod
                tempor incididunt.</p>
              </div>
            </a>
          </div>
        </div> -->
        <!-- <div class="col-lg-4">
          <div class="sngl-box">
            <a href="">
              <div class="imge-box">
                <img src="images/img3.png">
              </div>
              <div class="content-box">
                <h4>BCPNP</h4>
                <p>Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod
                tempor incididunt.</p>
              </div>
            </a>
          </div>
        </div> -->
        <!-- <div class="col-lg-4">
          <div class="sngl-box">
            <a href="">
              <div class="imge-box">
                <img src="images/img4.jpg">
              </div>
              <div class="content-box">
                <h4>LMIA</h4>
                <p>Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod
                tempor incididunt.</p>
              </div>
            </a>
          </div>
        </div> -->
        <!-- <div class="col-lg-4">
          <div class="sngl-box">
            <a href="">
              <div class="imge-box">
                <img src="images/img5.jpg">
              </div>
              <div class="content-box">
                <h4>Work permit</h4>
                <p>Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod
                tempor incididunt.</p>
              </div>
            </a>
          </div>
        </div> -->
        <!-- <div class="col-lg-4">
          <div class="sngl-box">
            <a href="">
              <div class="imge-box">
                <img src="images/img6.jpg">
              </div>
              <div class="content-box">
                <h4>Start up Visa Program</h4>
                <p>Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod
                tempor incididunt.</p>
              </div>
            </a>
          </div>
        </div> -->
        <!-- <div class="col-lg-4">
          <div class="sngl-box">
            <a href="">
              <div class="imge-box">
                <img src="images/img7.jpg">
              </div>
              <div class="content-box">
                <h4>Spousal Sponsorship</h4>
                <p>Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod
                tempor incididunt.</p>
              </div>
            </a>
          </div>
        </div> -->
      </div>
    </div>
  </div>
</div>

<?php get_footer(); ?>