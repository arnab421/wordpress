<style>
            .contact_frm .iti--separate-dial-code .iti__selected-flag {
                background-color: white !important;
            }

            .contact_frm .iti--allow-dropdown .iti__flag-container:hover .iti__selected-flag{
                background-color: white !important;
            }

            .contact_frm .iti--allow-dropdown .form-field{
                color: white !important;
                padding-top: max(.55vw, .55rem) !important;
                padding-bottom: max(.55vw, .55rem) !important;
            }

            .contact_frm .iti--allow-dropdown .form-field::placeholder{
                color: white;
            }

            .contact_frm .iti--allow-dropdown .form-field::-ms-input-placeholder{
                color: white;
            }
</style>
<form action="javascript:" class="form-style contact_frm allForm" id="get_in_touch">
<p class="h5 c--mbOrange">To discover how we can drive your efficiency and growth.</p>
    <div class="form-element colspan-2">
        <label class="form-label" aria-label="Full name">First Name <span class="c--mbOrange">*</span></label>
        <input name="gt_fname" id="gt_fname" type="text" class="form-field" autocomplete="off">
    </div>
    <div class="form-element colspan-2">
        <label class="form-label" aria-label="Full name">Last Name <span class="c--mbOrange">*</span></label>
        <input name="gt_lname" id="gt_lname" type="text" class="form-field" autocomplete="off">
    </div>
    <div class="form-element colspan-2">
        <label class="form-label" aria-label="Email">Email Address <span class="c--mbOrange">*</span></label>
        <input name="gt_email" type="text" class="form-field">
    </div>
    <div class="form-element colspan-2">
        <!-- <label class="form-label" aria-label="Phone">Phone Number <span class="c--mbOrange">*</span></label> -->
        <input name="gt_phone" type="tel" id="gt_phone" class="form-field">
        <span id="phoneErrorus" style="color: red; display: none; font-size: 60%;">Please enter a valid number from US.</span>
        <span id="phoneErrorca" style="color: red; display: none; font-size: 60%;">Please enter a valid number from Canada.</span>
    </div>
    <input type="hidden" id="hiddenField" class="country" name="country" value="">
    <div class="cta-container">
        <div class="form-element form-checkbox mb-0">
            <label>
                <!-- <input type="checkbox" name="callback_request" value="1"> -->
                <input type="checkbox" name="privacy_policy" value="1">
                <span class="checkmark"></span>
                <p>I accept the <a href="javascript:void(0)" class="terms-link fw--b" style="text-decoration: underline !important;">Terms</a> & <a href="javascript:void(0)" class="terms-link fw--b" style="text-decoration: underline !important;">Privacy Policy</a></p>
            </label>
        </div>
        
        <div class="form-element mb-0">
            <button class="btn dnt_btn btn-submit c2a c2a--inline bg--mbOrange c--mbWhite hvr:bg--mbBlack hvr:c--mbWhite w-100" id="rhl_git_sbmt_btn" type="submit" aria-label="Submit">
                <span>Let's Talk</span>
                <svg xmlns="http://www.w3.org/2000/svg" height="24px" viewBox="0 -960 960 960" width="24px" fill="#fff"><path d="M745.85-450.39H129.62q-12.75 0-21.38-8.62-8.62-8.63-8.62-21.39 0-12.75 8.62-21.37 8.63-8.61 21.38-8.61h616.23L572.38-684.46q-8.17-8.21-8.55-20.53-.37-12.32 8.55-21.31 8.18-8.24 20.82-8.24 12.65 0 20.95 8.31l220.54 220.54q5.62 5.61 7.92 11.9 2.31 6.28 2.31 13.46 0 7.18-2.32 13.64-2.33 6.46-7.91 12L614.15-234.15q-8.21 8.3-20.53 8.3-12.31 0-21.24-8.3-9.3-8.93-9.11-21.39.19-12.46 9.11-21.38l173.47-173.47Z"/></svg>
            </button>
        </div>
    </div>
</form>  
<!-- Phone Number Country get -->
<!-- <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.7.1/jquery.min.js"></script> -->
<!-- <script>
     jQuery(document).ready(function() {
        jQuery('#gt_phone').on('keyup', function() {
        var activeItem = jQuery('.iti__active');
        var countryCode = activeItem.data('country-code');
        console.log('Active country code:', countryCode);
        jQuery('.country').val(countryCode);
        });
   
    });
 </script> -->
 <!-- Phone Number Country get -->