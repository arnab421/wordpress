<?php
/**
 * The base configuration for WordPress
 *
 * The wp-config.php creation script uses this file during the installation.
 * You don't have to use the website, you can copy this file to "wp-config.php"
 * and fill in the values.
 *
 * This file contains the following configurations:
 *
 * * Database settings
 * * Secret keys
 * * Database table prefix
 * * ABSPATH
 *
 * @link https://developer.wordpress.org/advanced-administration/wordpress/wp-config/
 *
 * @package WordPress
 */

// ** Database settings - You can get this info from your web host ** //
/** The name of the database for WordPress */
define( 'DB_NAME', 'mb_landing_2_db' );

/** Database username */
define( 'DB_USER', 'root' );

/** Database password */
define( 'DB_PASSWORD', '' );

/** Database hostname */
define( 'DB_HOST', 'localhost' );

/** Database charset to use in creating database tables. */
define( 'DB_CHARSET', 'utf8mb4' );

/** The database collate type. Don't change this if in doubt. */
define( 'DB_COLLATE', '' );

/**#@+
 * Authentication unique keys and salts.
 *
 * Change these to different unique phrases! You can generate these using
 * the {@link https://api.wordpress.org/secret-key/1.1/salt/ WordPress.org secret-key service}.
 *
 * You can change these at any point in time to invalidate all existing cookies.
 * This will force all users to have to log in again.
 *
 * @since 2.6.0
 */
define( 'AUTH_KEY',         'Im[GrGd=%Am,_g,IiV=K@oc/e@OdB;MCz>n.QIj:[vsx gVACs/~jII:?sGRNPFL' );
define( 'SECURE_AUTH_KEY',  'lBj;Y}2)B6dRQp97:i$:Ffv*oQ!vMhQ&Vj<V]>!9o@*vu_O8rqzMG5fdf2*?V*iq' );
define( 'LOGGED_IN_KEY',    'NoSOvZZ*[P)<*6b:U6P8;tRJX&Fuf5KVL)z~DJ9NwIq3ks_7$KDU&=`Z/4i,W2w8' );
define( 'NONCE_KEY',        'l+IqoW<0hP)#uZ9:BNM/R^>P_BoPxso^Y<xU3SMz`X|}aXurs031+ULn9M9N?+SA' );
define( 'AUTH_SALT',        '[pjH<Bc~,2SlkW5e9 B@ES&pF1{k6}j,3mn[6LwaHgnWBo6E:q5:PR%ua*hxePUs' );
define( 'SECURE_AUTH_SALT', '>Ut+_<IFLz?8Y/(I2&KxB2F;b`vXmD(2K`Zd[0XPG {rysGqzg).UcJyf,U^I3$k' );
define( 'LOGGED_IN_SALT',   'Mg*CM{N*~-?_=M$fmZb}oMi{cjfJ)1&clY+(BnJQX 4.{/q#9nO1MWqK3L>y[[l/' );
define( 'NONCE_SALT',       '$xw.HVDYa8hyqo{OVljZss~dG`*kxH:)xW|??KYdbFsR_,U$WH7G+7DQ;e=y9IeV' );

/**#@-*/

/**
 * WordPress database table prefix.
 *
 * You can have multiple installations in one database if you give each
 * a unique prefix. Only numbers, letters, and underscores please!
 */
$table_prefix = 'mbl2_';

/**
 * For developers: WordPress debugging mode.
 *
 * Change this to true to enable the display of notices during development.
 * It is strongly recommended that plugin and theme developers use WP_DEBUG
 * in their development environments.
 *
 * For information on other constants that can be used for debugging,
 * visit the documentation.
 *
 * @link https://developer.wordpress.org/advanced-administration/debug/debug-wordpress/
 */
ini_set('display_errors','Off');
ini_set('error_reporting', E_ALL );
define('WP_DEBUG', true);
define('WP_DEBUG_DISPLAY', true);

/* Add any custom values between this line and the "stop editing" line. */



/* That's all, stop editing! Happy publishing. */

/** Absolute path to the WordPress directory. */
if ( ! defined( 'ABSPATH' ) ) {
	define( 'ABSPATH', __DIR__ . '/' );
}

/** Sets up WordPress vars and included files. */
require_once ABSPATH . 'wp-settings.php';
