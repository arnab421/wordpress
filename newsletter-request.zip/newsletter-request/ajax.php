<?php
require_once(dirname(dirname(dirname(dirname(__FILE__)))) . DIRECTORY_SEPARATOR . 'wp-load.php');
//Remove Contact Request
	add_action( 'wp_ajax_nopriv_ils_pre_remove', 'ils_pre_remove' );
	add_action( 'wp_ajax_ils_pre_remove', 'ils_pre_remove' );
//end
//contact request submission
	add_action( 'wp_ajax_nopriv_ils_pre_get_in_touch_form_submission', 'ils_pre_get_in_touch_form_submission' );
	add_action( 'wp_ajax_ils_pre_get_in_touch_form_submission', 'ils_pre_get_in_touch_form_submission' );
//end

//delete
	function ils_pre_remove(){
		$id = trim($_POST['id']);
		$nm_query = new ils_pre_data_query;
		$rec = $nm_query->removeById($id);
		if(!$rec){
			echo json_encode(['status' => 'error', 'message' => 'Record could not be deleted!']);exit;
		}
		echo json_encode(['status' => 'success', 'message' => 'Record deleted successfully!']);exit;
	}
//end

//Submission
function ils_pre_get_in_touch_form_submission() {
	if(isset($_POST['recaptcha_token']) && !empty($_POST['recaptcha_token'])) {
		$secretKey = '6LfbkjwqAAAAAOxUeO_Ko9ZPiVBZN2tbJGDemU15';
		$verifyResponse = file_get_contents('https://www.google.com/recaptcha/api/siteverify?secret='.$secretKey.'&response='.$_POST['recaptcha_token']);
		$response = json_decode($verifyResponse); 
		   if($response->success == 1){
			  $data = [];
   	          $data['gt_email'] 							= sanitize_text_field( $_POST['gt_email'] ); 
			  $data['gt_name'] 							= sanitize_text_field( $_POST['gt_name'] ); 
	          $data['added_on']							= date('Y-m-d h:i:s');
              pre_enroll_form_validation($data);
              complete_pre_enroll_form($data);
			  wp_send_json($response);
		   }
	   }
	
		else {
			echo '<p>Error: reCAPTCHA validation failed. Please try again.</p>';
		}
}
	
function check_email_exists($email) {
    global $wpdb;
    $table_name = $wpdb->prefix . 'newsletter_requests';
    $result = $wpdb->get_var($wpdb->prepare("SELECT COUNT(*) FROM $table_name WHERE gt_email = %s", $email));
	if($result > 0) {
		return true;
	}
	// return $result > 0;
	else {
		return false;
	}
} 

//Server side validation
// function pre_enroll_form_validation($data = []){
// 	global $form_errors;
// 	$form_errors = new WP_Error;
	
// 	if (
// 		empty( $data['gt_email'] ) || 
// 		empty( $data['gt_name'] )
// 	){
// 		$form_errors->add('field', 'Some of required form fields are missing');
// 	}
// }
function pre_enroll_form_validation($data = []) {
    global $form_errors;
    $form_errors = new WP_Error;
    if (empty($data['gt_email']) || empty($data['gt_name'])) {
        $form_errors->add('field', 'Some of required form fields are missing');
    }
    if (isset($data['gt_email']) && check_email_exists($data['gt_email'])) {
        $form_errors->add('email_exists', 'The email address is already subscribed');
    }
} 

// Access the global $form_errors variable


//DB checking
function complete_pre_enroll_form($data = []){
	global 	$wpdb,
	$form_errors; 
    if(count( $form_errors->errors) > 0){
    	echo json_encode(['status' => false, 'message' => 'Some of required form fields are missing']);exit;
    }   
    $success = get_option('ils_pre_success');
	$error = get_option('ils_pre_error');
	
	$sql = "SELECT * FROM `".$wpdb->prefix."newsletter_requests` WHERE `flag` = 0 AND `gt_email` = '".$data['gt_email']."'";
	$result = $wpdb->get_results( $sql, 'ARRAY_A' );
	if(count($result)>0){
		echo json_encode(['status' => false, 'message' => 'Email id already subscribed.']);exit;
	}
	$ip = '';
	if(!empty($_SERVER['HTTP_CLIENT_IP'])){
        //ip from share internet
        $ip = $_SERVER['HTTP_CLIENT_IP'];
    }elseif(!empty($_SERVER['HTTP_X_FORWARDED_FOR'])){
        //ip pass from proxy
        $ip = $_SERVER['HTTP_X_FORWARDED_FOR'];
    }else{
        $ip = $_SERVER['REMOTE_ADDR'];
    }

    $data['ip_addr'] = !empty($ip) ? $ip : 'NULL';
    $query = $wpdb->insert( $wpdb->prefix.'newsletter_requests', $data);

   // print_r($query);exit;

    if(!$query){
		
    	echo json_encode(['status' => false, 'message' => $error]);exit;
    }

	ils_pre_send_user_email($data);
    ils_pre_send_admin_email($data);
	//ils_pre_subscription_email_body($data);
	
    echo json_encode(['status' => true, 'message' => $success]);
	exit;

}


// //Email Template
function ils_pre_send_user_email($data = []){
	$mail 			= new SendEmail;	
	$from 			= get_option('ils_pre_email_from');
	$to 			= $data['gt_email'];
	//$cc 			= get_option('ils_pre_email_cc');
	$subject 		= get_option('ils_pre_user_email_subject');
	$template_body 	= get_option('ils_pre_user_email_body');

	$template_body 	= str_replace("{email}",$data['gt_email'],$template_body);

	$body 			= $mail->template($template_body);
	
	$headers 		= [
		'Content-Type: text/html; charset=UTF-8',
		'From: '.$from
	];

	wp_mail( $to, $subject, $body, $headers );		
}	

//Admin Email Template
function ils_pre_send_admin_email($data = []){
	//print_r(123); exit;
	$mail 			= new SendEmail;	
	$from 			= get_option('ils_pre_email_from');
	$to 			= get_option('ils_pre_email_to');
	$cc 			= get_option('ils_pre_email_cc');
	$subject 		= get_option('ils_pre_admin_email_subject');
	$template_body 	= get_option('ils_pre_admin_email_body');

	$template_body 	= str_replace("{email}",$data['gt_email'],$template_body);
	
	
	$template_body 	= str_replace("{ip}",$data['ip_addr'],$template_body);

	$body 			= $mail->template($template_body);
	$headers 		= [
		'Content-Type: text/html; charset=UTF-8',
		'From: '.$from, 
    	'Cc: '.$cc,
    	'Reply-To: '.$data["email"].' <'.$data["email"].'>'
	];

	wp_mail( $to, $subject, $body, $headers );
}
?>