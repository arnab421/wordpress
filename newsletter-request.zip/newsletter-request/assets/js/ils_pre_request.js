jQuery(document).ready(function () {
	//Form validation
	jQuery.validator.addMethod("customemail", function (value, element, params) {
		var re = /^[a-z0-9]+([-._][a-z0-9]+)*@([a-z0-9]+(-[a-z0-9]+)*\.)+[a-z]{2,4}$/;
		return re.test(value);
	}, "Please enter a valid email address.");
	jQuery.validator.addMethod("nameRegex", function (value, element) {
		return this.optional(element) || /^[a-zA-Z\ , .!'\s]+$/i.test(value);
	}, "Please enter only alphabetic characters.");
	jQuery('#new_get_in_touch').validate({
		errorElement: "i",
		errorClass: "error",
		ignore: '',
		rules: {
			gt_email: {
				required: true,
				customemail: true
			},
			gt_name: {
				required: true,
				nameRegex: true,
				minlength: 2
			}
		},
		messages: {
			gt_email: {
				required: "Please enter your email",
				customemail: "Please enter valid email",
			},
			gt_name: {
				required: "Please enter your full name",
				minlength: "Full name should contain minimum two characters"
			}
		},
		submitHandler: function (form) {
			show_loader(form);
			jQuery("#ils_pre_sbmt_btn").prop('disabled', true);
			jQuery("#ils_pre_sbmt_btn").text('Please wait');
			//jQuery(".wait-message").text('Please wait...');
			 grecaptcha.ready(function() {
				grecaptcha.execute('6LfbkjwqAAAAAO8gEz9JwhWoGe5t9s0Vs2bkgMoa', {action: 'submit'}).then(function(token) {
					// Add your logic to submit to your backend server here.
					let allData = new FormData(form);
					allData.append('action', 'ils_pre_get_in_touch_form_submission');
					allData.append('recaptcha_token', token);  // Append the reCAPTCHA token
					jQuery.ajax({
						url: ils_pre_form_submission.ajax_url,
						type: 'POST',
						data: allData,
						dataType: "json",
						cache: false,
						processData: false,
						contentType: false,
						success: function (response) {
							jQuery("#ils_pre_sbmt_btn").prop('disabled', false);
							//jQuery(".wait-message").html('');
							jQuery("#ils_pre_sbmt_btn").html('<span>Subscribe</span>');
							jQuery('#new_get_in_touch')[0].reset();
							hide_loader(form);
							// show_message(response, form);
							//window.location.href = "/thank-you-page/";
							jQuery(".sundew-ui--modal-outer").hide();
							Swal.fire({
								title: 'Success!',
								text: 'Subscribed.',
								icon: 'success',
								showConfirmButton: false, 
								timer: 4000 
							});
							setTimeout(function() {
								jQuery(".sundew-ui--modal-outer").show();
							}, 4100); 
						},
						error: function (xhr) {
							hide_loader(form);
							// console.log(xhr.responseText);
							Swal.fire({
								title: 'Error!',
								text: 'There was a problem with your submission.',
								icon: 'error',
								confirmButtonText: 'Try Again'
							});
						}
					});
				});
			});
			
		}
	});
})

//show the loader
function show_loader(form) {
	jQuery(form).find('.btn-submit').attr('disabled', true).val('Please Wait');
}
//hide the loader
function hide_loader(form) {
	jQuery(form).find('.btn-submit').attr('disabled', false).val('Submit');

}