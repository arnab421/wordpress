<!-- <form action="javascript:void(0);" class="form allForm form-element" id="new_get_in_touch">
    <label class="form-label" for="gt_email">Enter your email</label>
    <input type="email" name="gt_email" id="gt_email" class="form-field" aria-label="Enter your email">
    <button type="submit" class="btn btn-submit submit_btn" id="ils_pre_sbmt_btn" aria-label="Newsletter">
        <svg xmlns="http://www.w3.org/2000/svg" height="24px" viewBox="0 -960 960 960" width="24px" fill="currentColor">
            <path d="M764.69-460.77H139.23q-8.5 0-14.25-5.76-5.75-5.75-5.75-14.27 0-8.51 5.75-14.24t14.25-5.73h625.46L572.77-692.92q-5.36-5.43-5.6-13.56-.25-8.14 5.6-14.12 5.36-5.48 13.64-5.48 8.28 0 13.9 5.62l217.07 217.08q5.24 5.23 7.35 10.79 2.12 5.56 2.12 11.92t-2.15 12.29q-2.15 5.92-7.32 11L600.31-240.31q-5.43 5.62-13.56 5.62t-13.98-5.62q-6.62-5.84-6.23-14.27.38-8.42 6.23-14.27l191.92-191.92Z" />
        </svg>
    </button>

    <div class="wait-message"></div>
</form> -->
<form action="javascript:void(0);" class="form-style-4" id="new_get_in_touch">
    <div class="form-element">
        <label for="" class="form-label">Email Address</label>
        <!-- <input type="text" class="form-field"> -->
        <input type="email" name="gt_email" id="gt_email" class="form-field" aria-label="Enter your email">
    </div>
    <div class="form-element">
        <label for="" class="form-label">Name</label>
        <!-- <input type="text" class="form-field"> -->
        <input type="text" name="gt_name" id="gt_name" class="form-field" aria-label="Enter your name">
    </div>
    <div class="form-element mt-2">
        <button type="submit" class="c2a bg--nadkarniMidCream c--nadkarniDarkBrown radius:expandedX2 size:expandedX w-100p hvr:bg--nadkarniDarkBrown hvr:c--nadkarniWhite" id="ils_pre_sbmt_btn"><span>Subscribe</span></button>
    </div>
</form>
<script defer>
    var rendercaptcha = false;
    function recaptchaRender() {
        const script = document.createElement('script');
        script.type = 'text/javascript';
        script.async = true;
        script.onload = () => onloadCallback();
        script.src = "https://www.google.com/recaptcha/api.js?render=6LfbkjwqAAAAAO8gEz9JwhWoGe5t9s0Vs2bkgMoa";
        document.head.appendChild(script);
    }
    if (rendercaptcha == false) {
        setTimeout(recaptchaRender, 6000);
        
    }
    
    var onloadCallback = function () {
        if(grecaptcha) {
            rendercaptcha = true;
            console.log('Captcha Loaded');
        }
    }
</script>
